#Bienvenido al Scratchbook
#Welcome to the Scratchbook
def main():
  a = 2 + 2
  print(a)

main()