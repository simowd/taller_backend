USE taller;
INSERT INTO language(id_language, language) VALUES
    ("es", "español"),
    ("en", "english");

USE testing;
INSERT INTO language(id_language, language) VALUES
    ("es", "español"),
    ("en", "english");