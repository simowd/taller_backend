USE taller;
INSERT INTO gender(id_gender, gender) VALUES
    ("1", "Hombre"),
    ("2", "Mujer"),
    ("3", "Prefiero no decirlo"),
    ("4", "Otro");

USE testing;
INSERT INTO gender(id_gender, gender) VALUES
    ("1", "Hombre"),
    ("2", "Mujer"),
    ("3", "Prefiero no decirlo"),
    ("4", "Otro");